DSWG Small Map Icons
1.13 - 1.19+
By Daswaget
Patreon: https://www.patreon.com/daswaget